
% 3TM - HH dipolar interations
% This fitting process is for paramagnetics within solid
% 
% D Faux October 2019
%
% USER - choose input expt data set and output file names

expt_data_set =     'ExptMortar.dat';
fitSummaryOutput =  '3TM-fitSummary-HM-mor-3.out';
fid=fopen(fitSummaryOutput,'wt');    % open output with identifier fid

data = dlmread(expt_data_set);
Freq=data(:,1);
R1Xp=data(:,2);

figure;
semilogx(Freq,R1Xp,'o')
xlabel('(MHz)');
ylabel('R_1 (s^{-1})');
legend('R1Xp');
title(['R1 measured versus Freq    ',expt_data_set])
drawnow


%================================================================= 
% Do not change these numbers - these are the read data set values
 Nb = 22;   Nd = 33;    NL = 65;    Nf = 201;
 NFreq = size(Freq,1);      % the number of expt frequencies
 acc = 0.000001;
%================================================================= 
 
 No_chi_start = 1;          % The chi^2 will be calculated for frequencies No_chi_start:No_chi_end
 No_chi_end = NFreq;        % the output data and the plot will provide all the data points from 1:NFreq regardless
                            % of the choices here for both the experimental data and the fit, even though the best fit is
                            % obtained for the range No_chi_start:No_chi_end

 Npara = 50;               % No. values tested for paramagnetics density e-spins/nm^3
 Npara_start = 0.0250;      % starting value of paramagnetics density e-spins/nm^3 for fit
 dNpara =      0.0001;      % change in value of paramagnetics density e-spins/nm^3 for fit
                   
 Nx = 50;                   % number of x values to be searched
 x_start = 0.00055;          % starting x value (x=S/V ratio)
 dx =      0.00001;        % change in x value  
 
 chi_style = 'lin';         % 'lin' for linear least squares
                            % 'log' for logarithmic (10) least squares
 
 sensitivity_factor = 1.02; % range of chi^2 = sensitivity_factor * chi^2 min
                            % this means that all fits within sensitivity_factor of the 
                            % optimum (min) chi2 is deemed a "good" fit
                            
 Ng = 9;                    % number of x and Nlayer trials for sensitivity
                            % If optimum fit has (x,N) pair, and Ng=5, then
                            % x-2dx, x-dx, x, x+dx, x+2dx are explored
                            % ditto No. spins in surface layer Nlayer
                            
 max_good = 2000;           % The maximum number of "good" fits
 opt_good_index = 0;
 
 T1T2_freq = 20.0;          % frequency in MHz for T1/T2 calculation 
 
 %%%  set the arrays ==============================================

 R1_L = zeros(NL,Nd,Nb,Nf);     
 R2_L = zeros(NL,Nd,Nb,Nf);     
 R1_b = zeros(NL,Nd,Nb,Nf);        
 R2_b = zeros(NL,Nd,Nb,Nf);
 
 % these arrays for reading data from file
 R1_L_d = zeros(NL*Nd*Nf,1);      R2_L_d = zeros(NL*Nd*Nf,1);
 R1_b_d = zeros(Nb*Nf,1);         R2_b_d = zeros(Nb*Nf,1);
 
 R1_L_T1T2 = zeros(NL,Nd,Nb);  R2_L_T1T2 = zeros(NL,Nd,Nb);
 R1_b_T1T2 = zeros(NL,Nd,Nb);  R2_b_T1T2 = zeros(NL,Nd,Nb);
 
 R1_L_ind = zeros(NL,Nd,Nb,NFreq);      R1_b_ind = zeros(NL,Nd,Nb,NFreq);
 R1 = zeros(NL,Nd,Nb,NFreq);            %R2 = zeros(NL,Nd,Nb,NFreq);
 R1Xp_ind = zeros(NL,Nd,Nb,NFreq);
 R1Th = zeros(NFreq,1);                 %R2Th = zeros(NFreq,1);
 Resid = zeros(NFreq,1);                % fit residuals
 
 R1_L_indx = zeros(NFreq,1);            %R2Th = zeros(NFreq,1);
 
 chi2_f = zeros(NL,Nd,Nb,NFreq);        %chi2_f_opt = zeros(NL,Nd,Nb,NFreq);
 chi2 = zeros(NL,Nd,Nb);                %chi2_opt = zeros(NL,Nd,Nb);
 
 x_pick = zeros(Ng,1);
 N_pick = zeros(Ng,1);
 
 % for sensitivity analysis
 tau_L_good = zeros(max_good,1);       
 tau_d_good = zeros(max_good,1);        tau_b_good = zeros(max_good,1);
 x_good = zeros(max_good,1);            N_good = zeros(max_good,1);
 tL_index = zeros(max_good,1);
 td_index = zeros(max_good,1);          tb_index = zeros(max_good,1);
 T1T2_good = zeros(max_good,1);
 chi2_good = zeros(max_good,1);         

 R1_good = zeros(max_good,NFreq);
 
 tau_L = zeros(NL,1);
 tau_d = zeros(NL,Nd);
 tau_d_in = zeros(NL*Nd,1);
 tau_b = zeros(Nb,1);
 
 Freq_th = zeros(Nf,1);         lg_Freq_th = zeros(Nf,1);
 Freq_ind = zeros(NFreq,1);     lg_Freq = zeros(NFreq,1);
 
 x = zeros(Nx,1);                 % s/v ratio values and dx increment
 for i=1:Nx; x(i,1)=x_start + i*dx; end       

 N = zeros(Npara,1);         % Nlayer values and dNlayer increment
 for i=1:Npara; N(i,1)=Npara_start+((i-1)*dNpara); end
 
 NxN = Npara*Nx;
 xx = zeros(NxN,1);
 NN = zeros(NxN,1);
 min_chi2 = zeros(NxN,1);
 
%%%  end set the arrays ==============================================

%%% Read in data sets

 fprintf('\n Reading input relaxation rate data sets ... \n');
 
 Freq_th=dlmread('Freq_th.dat');   % all frequencies for theory R1
 tau_L = dlmread('tau_L.dat');
 tau_d_in = dlmread('tau_d.dat');
 tau_b = dlmread('tau_b.dat');
 R1_L_d = dlmread('R1_L_Fe.dat');
 R1_b_d = dlmread('R1_b_Fe.dat');
 R2_L_d = dlmread('R2_L_Fe.dat');
 R2_b_d = dlmread('R2_b_Fe.dat');
 
 fprintf('... input relaxation rate data sets read successfully \n\n');
 fprintf('Preparing fitting arrays .... \n');
 
 % Find the theory frequency indexes that best correspond to expt f
  
 for i=1:NFreq
      
    delta_f(:,1) = abs(log10(Freq_th(:,1)) - log10(Freq(i,1)));
    minimum = min(delta_f);
  
    Freq_ind(i,1) = find(delta_f == minimum);
    
 end
 
 lg_Freq = log10(Freq);
 lg_Freq_th = log10(Freq_th);
  
  % Here the index in the list of theory frequencies that corresponds to
  % T1T2_freq is found
  
  delta_T1T2(:,1) = abs(Freq_th(:,1) - T1T2_freq);
  minimum = min(delta_T1T2);
  T1T2_index = find(delta_T1T2 == minimum);
  

% Reorganise arrays 

tcount = 0;
for iL=1:NL                 % reorganise tau_d read input into array
    for id=1:Nd
        tcount = tcount+1;
        tau_d(iL,id) = tau_d_in(tcount);
    end
end

RcountL = 0;
for iL=1:NL                 % reorganise read input into 4D arrays
    for id=1:Nd
        RcountL = RcountL + 1;
        
        for ib=1:Nb

            R1Xp_ind(iL,id,ib,1:NFreq) = R1Xp(1:NFreq);
            
            for ifr=1:Nf
            Rindexb = (ib-1)*Nf + ifr;
            RindexL = (RcountL-1)*Nf + ifr;

            R1_L(iL,id,ib,ifr) = R1_L_d(RindexL,1);
            R1_b(iL,id,ib,ifr) = R1_b_d(Rindexb,1);
            R2_L(iL,id,ib,ifr) = R2_L_d(RindexL,1);
            R2_b(iL,id,ib,ifr) = R2_b_d(Rindexb,1);
            end
            
            R1_L_T1T2(iL,id,ib) = R1_L(iL,id,ib,T1T2_index);
            R1_b_T1T2(iL,id,ib) = R1_b(iL,id,ib,T1T2_index);
            R2_L_T1T2(iL,id,ib) = R2_L(iL,id,ib,T1T2_index);
            R2_b_T1T2(iL,id,ib) = R2_b(iL,id,ib,T1T2_index);

        end
    end
end


% Here we match the theory log10 frequencies to expt frequencies for fitting
% and use quadratic scaling to obtain the best R1_L and R1_b at the 
% expt frequency interpolated between the theory log10 frequencies

d_log_freq_th = lg_Freq_th(2,1) - lg_Freq_th(1,1);

for iL=1:NL                 
    for id=1:Nd
        for ib=1:Nb  
            for i=1:NFreq
                
              ind = Freq_ind(i,1);
                
              xlgfXp = (lg_Freq(i,1) - lg_Freq_th(ind-1,1))/d_log_freq_th;
              factor0 = (xlgfXp-1)*(xlgfXp-2)/2;
              factor1 = -xlgfXp*(xlgfXp-2);
              factor2 = xlgfXp*(xlgfXp-1)/2;
              
              R1_b_ind(iL,id,ib,i) =  factor0*R1_b(iL,id,ib,ind-1) + ...
                                      factor1*R1_b(iL,id,ib,ind) + ...
                                      factor2*R1_b(iL,id,ib,ind+1);
                
              R1_L_ind(iL,id,ib,i) =  factor0*R1_L(iL,id,ib,ind-1) + ...
                                      factor1*R1_L(iL,id,ib,ind) + ...
                                      factor2*R1_L(iL,id,ib,ind+1);
            end    
        end
    end
end

fprintf('... fitting arrays complete \n\n');
fprintf('Starting fit ... \n');

%%% Here the fitting starts - find best x and N for each tau

% The sole purpose of the initial scoping is to locate the global min chi^2
% fit parameter for each (x,N) pairing for each tau_L, tau_d and tau_b

xN_count = 0;
for ix=1:Nx                 % x loop
    
    for iN=1:Npara          % N loop

    xN_count = xN_count + 1;
    
    xx(xN_count,1) = x(ix,1);
    NN(xN_count,1) = N(iN,1); 
    
    R1 = N(iN,1)*(1-x(ix,1))*R1_b_ind + N(iN,1)*x(ix,1)*R1_L_ind;        % Calculate R1
    
    if strcmp(chi_style,'log')
        
        for i=No_chi_start:No_chi_end
        chi2_f(:,:,:,i) = (log10(R1(:,:,:,i)) - log10(R1Xp_ind(:,:,:,i))).^2;          % log chi^2
        end
        
    elseif strcmp(chi_style,'lin')
        
        for i=No_chi_start:No_chi_end
        chi2_f(:,:,:,i) = (R1(:,:,:,i) - R1Xp_ind(:,:,:,i)).^2;                        % lin chi^2
        end
        
    end
    
    chi2 = sum(chi2_f,4);                               % sum chi^2 for each expt frequency
   
    min_chi2(xN_count,1) = min(min(min(chi2)));      % global minimum chi^2 value for this x and Nlayer
    
    end
end

global_min_chi2 = min(min_chi2);                    % This is the global minimum chi^2
i_opt = find(min_chi2 == global_min_chi2);          % This is the index for its xNlayer_count
x_opt = xx(i_opt,1);                                % This is the corresponding x at global min
N_opt = NN(i_opt,1);                                % This is the corresponding Nlayer at global min

chi2_max = global_min_chi2*sensitivity_factor;      % Now we can define max chi2 for "good" fit 

% Sensitivity check here
% We pick a small group of x and N values around the optimum values
% These are the values of x and N around the optima to be picked

Ngc = round(Ng/2);                  % This means that Ngc=3 if Ng=5
for ix=1:Ng
    x_pick(ix,1) = x_opt - (ix-Ngc)*dx;
end
for iN=1:Ng
    N_pick(iN,1) = N_opt - (iN-Ngc)*dNpara;
end

good_fit_count = 0;
for ix=1:Ng             % x loop over number of good-fit trials
    
    for iN=1:Ng         % Nlayer loop over number of good-fit trials
    
    R1 = N_pick(iN,1)*(1-x_pick(ix,1))*R1_b_ind + ...
         N_pick(iN,1)*x_pick(ix,1)*R1_L_ind;                % Calculate R1
    
    for i=No_chi_start:No_chi_end
        if strcmp(chi_style,'log')
            chi2_f(:,:,:,i) = (log10(R1(:,:,:,i)) - log10(R1Xp_ind(:,:,:,i))).^2;          % log chi^2  
        elseif strcmp(chi_style,'lin') 
            chi2_f(:,:,:,i) = (R1(:,:,:,i) - R1Xp_ind(:,:,:,i)).^2;                        % lin chi^2
        end  
    end
    
    chi2 = sum(chi2_f,4);                               % sum chi^2 for each expt frequency  

    for iL=1:NL                 % find good fit data
        for id=1:Nd
            for ib=1:Nb
    
                if chi2(iL,id,ib) < chi2_max            % if the fit quality chi^2 is good
                good_fit_count = good_fit_count + 1;
                
                    if good_fit_count > max_good
                        fprintf('Increase max_good \n')
                    end
                    
                tL_index(good_fit_count,1) = iL;
                tau_L_good(good_fit_count,1) = tau_L(iL,1)/1000000;
                td_index(good_fit_count,1) = id;
                tau_d_good(good_fit_count,1) = tau_d(iL,id)/1000000;
                tb_index(good_fit_count,1) = ib;
                tau_b_good(good_fit_count,1) = tau_b(ib,1);
                x_good(good_fit_count,1) = x_pick(ix,1);
                N_good(good_fit_count,1) = N_pick(iN,1);
                chi2_good(good_fit_count,1) = chi2(iL,id,ib);
                
                R1_good(good_fit_count,1:NFreq) = ...
                    N_good(good_fit_count,1)*(1-x_good(good_fit_count,1))*R1_b_ind(iL,id,ib,1:NFreq) + ...
                    N_good(good_fit_count,1)*x_good(good_fit_count,1)*R1_L_ind(iL,id,ib,1:NFreq);
                
                for i=1:NFreq
                R1_L_indx(i,1) = R1_L_ind(iL,id,ib,i);
                end
                
                R1T1T2 = N_good(good_fit_count,1)*(1-x_good(good_fit_count,1))*R1_b_T1T2(iL,id,ib) + ...
                    N_good(good_fit_count,1)*x_good(good_fit_count,1)*R1_L_T1T2(iL,id,ib);  % Calculate R1 at frequency for T1/T2
                R2T1T2 = N_good(good_fit_count,1)*(1-x_good(good_fit_count,1))*R2_b_T1T2(iL,id,ib) + ...
                    N_good(good_fit_count,1)*x_good(good_fit_count,1)*R2_L_T1T2(iL,id,ib);
                
                T1T2_good(good_fit_count,1) = R2T1T2/R1T1T2;

                end
            end
        end
    end
    
    end
end

min_chi2_good = min(chi2_good(1:good_fit_count,1));

for i = 1:good_fit_count
    if (abs(chi2_good(i,1) - min_chi2_good) < acc)        
        opt_good_index = i; 
    end  
end

if opt_good_index == 0
    fprintf('Warning: opt_good_index == 0 \n')
end
    
h = 0.54/x_good(opt_good_index,1)/1000;    % "planar pore equivalent" thickness (0.54 nm surface converted to um)

tL = tau_L_good(opt_good_index,1);      % in um
tD = tau_d_good(opt_good_index,1);      % in um
tB = tau_b_good(opt_good_index,1);      % in ps 

ave_log_L = 0.000; ave_log_d = 0.000;  ave_log_b = 0.000;

for i=1:good_fit_count
    ave_log_L = ave_log_L + log10(tau_L_good(i,1))/good_fit_count;
    ave_log_d = ave_log_d + log10(tau_d_good(i,1))/good_fit_count;
    ave_log_b = ave_log_b + log10(tau_b_good(i,1))/good_fit_count;
end

min_L = min(tau_L_good(1:good_fit_count,1));
max_L = max(tau_L_good(1:good_fit_count,1));

min_d = min(tau_d_good(1:good_fit_count,1));
max_d = max(tau_d_good(1:good_fit_count,1));

min_b = min(tau_b_good(1:good_fit_count,1));
max_b = max(tau_b_good(1:good_fit_count,1));

mean_L = 10^ave_log_L;
mean_d = 10^ave_log_d;
mean_b = 10^ave_log_b;

T1T2_min = min(T1T2_good(1:good_fit_count));
T1T2_max = max(T1T2_good(1:good_fit_count));
    
% This is the 3-tau model R1 best fit
R1Th(:,1) = R1_good(opt_good_index,:);

Resid(:,1) = R1Th(:,1)-R1Xp(:,1);

fprintf('... fitting complete \n\n');
fprintf('Writing output ... \n');


% This is where the output results are written

fprintf(fid,expt_data_set);
fprintf(fid,'     \n'); 
if strcmp(chi_style,'lin')
    formatSpec = 'Linear least squares fitting  \n';
else
    formatSpec = 'Logarithmic least squares fitting  \n';
end
fprintf(fid,formatSpec); 
formatSpec = '  Fit start data %16d     Fit end data %16d\n';
fprintf(fid,formatSpec,No_chi_start,No_chi_end);
fprintf(fid,'     \n');fprintf(fid,'     \n');

fprintf(fid,'       frequency        R1 (expt)         R1 (3TM)         residual\n' );
fprintf(fid, '%16.4f %16.4f %16.4f %16.4f\n', [Freq R1Xp R1Th Resid]');
fprintf(fid,'     \n');

fprintf(fid,'     \n');

fprintf(fid,'BEST FIT RESULTS \n');

formatSpec = '         tau_L = %16.3f               us\n';
fprintf(fid,formatSpec,tL);
formatSpec = '         tau_d = %16.3f               us\n';
fprintf(fid,formatSpec,tD);
formatSpec = '         tau_b = %16.3f               ps\n';
fprintf(fid,formatSpec,tB);

fprintf(fid,'     \n');

formatSpec = '            N  = %16.3f   e-spins per nm^3 \n';
fprintf(fid,formatSpec,N_opt);
formatSpec = '            x  = %16.6f   surf/vol ratio \n';
fprintf(fid,formatSpec,x_opt);
formatSpec = '            h  = %16.3f          microns \n';
fprintf(fid,formatSpec,h); 
fprintf(fid,'     \n'); 
formatSpec = '     min chi2  = %16.5f \n';
fprintf(fid,formatSpec,global_min_chi2); 
fprintf(fid,'     \n'); 

formatSpec = 'opt tauL index = %16d \n';
fprintf(fid,formatSpec,tL_index(opt_good_index,1));
formatSpec = 'opt taud index = %16d \n';
fprintf(fid,formatSpec,td_index(opt_good_index,1));
formatSpec = 'opt taub index = %16d \n';
fprintf(fid,formatSpec,tb_index(opt_good_index,1));
fprintf(fid,'     \n'); 

formatSpec = ' For chi2 within %16.3f     of best chi2  \n';
fprintf(fid,formatSpec,sensitivity_factor);
fprintf(fid,'     \n'); 

for i=1:good_fit_count
    formatSpec = '      good fit = %16d \n';
    fprintf(fid,formatSpec, i);
    formatSpec = '         tau_L = %16.3f \n';
    fprintf(fid,formatSpec, tau_L_good(i,1));
    formatSpec = '         tau_d = %16.3f \n';
    fprintf(fid,formatSpec, tau_d_good(i,1));
    formatSpec = '         tau_b = %16.3f \n';
    fprintf(fid,formatSpec, tau_b_good(i,1));
    formatSpec = '             x = %16.6f \n';
    fprintf(fid,formatSpec, x_good(i,1));
    formatSpec = '        Nlayer = %16.6f \n';
    fprintf(fid,formatSpec, N_good(i,1));
    formatSpec = '          chi2 = %16.6f \n';
    fprintf(fid,formatSpec, chi2_good(i,1));
end

formatSpec = '     \n';
fprintf(fid,formatSpec);

formatSpec = '   tau_L range = %16.3f               to %16.3f              us\n';
fprintf(fid,formatSpec,min_L,max_L);
formatSpec = '   tau_d range = %16.3f               to %16.3f              us\n';
fprintf(fid,formatSpec,min_d,max_d);
formatSpec = '   tau_b range = %16.3f               to %16.3f              ps\n';
fprintf(fid,formatSpec,min_b,max_b);
formatSpec = '     \n';
fprintf(fid,formatSpec);

formatSpec = 'Spread means \n';
fprintf(fid,formatSpec);
formatSpec = '    mean tau_L = %16.3f \n';
fprintf(fid,formatSpec, mean_L);
formatSpec = '    mean tau_d = %16.3f \n';
fprintf(fid,formatSpec, mean_d);
formatSpec = '    mean tau_b = %16.3f \n';
fprintf(fid,formatSpec, mean_b);
formatSpec = '     \n';
fprintf(fid,formatSpec);

fprintf(fid,'     \n');

formatSpec = '    min chi^2  = %16.5f  \n';
fprintf(fid,formatSpec,min_chi2_good);
formatSpec = '     T1T2 min  = %16.3f     T1T2 max  = %16.3f \n';
fprintf(fid,formatSpec,T1T2_min,T1T2_max);

fclose(fid);true;

%%%%% plot experimental and theoretical R1 vs Freq  %%%%%%%%%%%%%%%%%%%%%%%

figure;
%hold on;
%R1Th=model(Par);
semilogx(Freq, R1Th,'b', Freq, R1Xp,'o')
title ('R1 measured and R1 theoretical versus Freq');
xlabel('(kHz)');
ylabel('R_1 (s^{-1})');
legend('R1Th','R1Xp');
%hold off

fprintf('\n FIT COMPLETE!!\n');


